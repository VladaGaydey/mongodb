const request = require("request");
const MongoClient = require("mongodb").MongoClient;
const url = "mongodb://localhost:27017/";
const mongoClient = new MongoClient(url, { useNewUrlParser: true });
var uri = 'https://www.shazam.com/shazam/v2/ru/UA/web/-/tracks/world-chart-world?pageSize=200&startFrom=0'
request(uri, (err, response, json) => {
    if (!err) {

        mongoClient.connect(function(err, client){
      
            const db = client.db(`mydb`);
            const collection = db.collection(`charts`);
            var obj = JSON.parse(json);

            for (var i = 0; i < 200; i++) {
                collection.insertOne({chart: `${obj['chart'][i]['share']['subject']}`, href: `${obj['chart'][i]['share']['href']}` }, function(err, result){
                    if(err){ return console.log(err) }
                });
            }
            client.close();
            
        });
    }
});


